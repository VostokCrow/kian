<?php include("lang/langconfig.php"); ?>
<!DOCTYPE html>
<html lang="<?php echo $_SESSION['lang']; ?>">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible"
        content = "IE=edge">
        <meta name="viewport" content="width=device,
        initial-scale=1.0">
        <link rel ="stylesheet" href="css/styleindex.css">
        <title>Welcome</title>
      </head>
<body>
    <a href="?lang=fr"><img src="img/fr.png" alt="Image du drapeau Francais" class="flag"></a>
    <a href="?lang=en"><img src="img/en.png" alt="Image du drapeau britannique" class="flag"></a>
    <header>    
        
        <?php include('php/navbar.php'); ?>
    </header>
    
    <section id="portefolio">
      <div class="portfolio-header">
        <h2><?php echo $lang['welcome']; ?></h2>
      </div>
        <button id="more-projects"><?php echo $lang['moreproject'];?></button>
          <div class="projects-container">
            <ul class="projects">
              <li class="project" id="placeholder" style="display:none;">
                <div class="project-info"></div>
              </li>
          </div>
    </section>
    
    
    <?php include('php/footer.php'); ?>
    <script>
        const lang = "<?php echo $_SESSION['lang']; ?>";
    </script>
    <script src="js/navbarscript.js"></script>
    <script src="js/ajaxpagination.js"></script>
    
</body>
</html>

