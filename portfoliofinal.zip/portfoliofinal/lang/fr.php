<?php
$lang = array(

    //page d'accueil
    "welcome" => "Bienvenue sur mon Portefolio.",
    "projects" => "Mes Projets",
    "footer" => "© Portefolio réalisé par Abdolmohammadian Kian",
    "french" => "Français",
    "english"=> "Anglais",
    "language" => "Langue :",
    "change" => "Changer",
    "moreproject" => "Voir mes projets",

    //Barre de navigation
    "homepage" => "Accueil",
    "project" => "Projets",
    "contact" => "Contact",
    "about" => "À propos de moi",


    //page de contact
    "name"=> "Nom",
    "prenom" => "Prénom",
    "email" => "E-mail",
    "message" => "Message",
    "envoyer" => "Envoyer",
    "titlecontact" => "Contactez-moi",

    //page a propos 

    "textabout" => "Je suis Abdolmohammadian Kian, un étudiant en 2ème année de licence d'Informatique à l'Université de Strasbourg. J'aime le code et je crée notamment du contenu avec Python.",
    "competence" => "Compétences",
    "html" => "HTML/CSS",
    "python" => "Python",
    "c" => "C",
    "java" => "Java",
    "educationtitle" => "Education",
    "educationtext" => "J'ai obtenu un Baccalauréat spécialités Mathématiques, Physique-Chimie et SVT mention Bien. J'ai étudié en Mesures Physiques pendant 1 an, je prépare actuellement ma licence d'Informatique. ",
    "experiencetitle" => "Experience",
    "experiencetext" => "J'étudie l'informatique depuis presque 2 ans maintenant, j'ai néanmoins effectué quelques projets, que ce soit dans le cadre des enseignements ou de façon personnel.",
    "experienceguessr" => "GuessrBot : Projet personnel de bot discord",
    "experiencesoko" => "Sokoban : Projet de groupe en lien avec la licence",
    "experienceconduite" => "Application de conduite : Projet seul en lien avec la licence",
    "centreinteret" => "Centres d'intérêts",
    "centreinterettext" => "En dehors du code, j'aime jouer au jeux vidéo, voyager et jouer au volley-ball avec mes amis.",
    "contacttext" => "Pour tout renseignement et questions, ainsi que des propositions, vous pouvez me contacter par mail ou utiliser le formulaire de contact.",
    "contactemail" => "Email: kian.abm67@gmail.com",

    //page projet

    "titleprojet" => "Mes différents travaux",
    "guessrtitle" => "GuessrBot",
    "guessrtext" => "Bot discord proposant des quizz de géographie, présent sur plus de 350 serveurs. Projet personnel réalisé depuis 1 an.",
    "sokotitle" => "Sokoban",
    "sokotext" => "Reconstitution du jeu Sokoban en langage C sur le terminal. Projet réalisé en groupe dans le cadre de la licence.",
    "conduitetitle" => "Application de conduite",
    "conduitetext" => "Site permettant d'enregistrer ses sessions de conduite. Projet réalisé seul dans le cadre de la licence.",
    "conduitelink" => "Conduite",

    
);
?>
