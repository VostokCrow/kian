<?php
session_start();

if(isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
}

if(!isset($_SESSION['lang'])) {
    $_SESSION['lang'] = 'fr'; 
}

if($_SESSION['lang'] == 'en') {
    include('lang/en.php');
} else {
    include('lang/fr.php');
}
?>