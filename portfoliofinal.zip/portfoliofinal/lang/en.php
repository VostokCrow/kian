<?php
$lang = array(

    //page d'accueil
    "welcome" => "Welcome to my Portfolio.",
    "projects" => "My Projects",
    "footer" => "© Portfolio created by Abdolmohammadian Kian",
    "french" => "French",
    "english"=> "English",
    "language" => "Language :",
    "change" => "Change",
    "moreproject" => "See my projects",

    //barre de navigation
    "homepage" => "Home",
    "project" => "Projects",
    "contact" => "Contact",
    "about" => "About me",

    //page de contact
    "name"=> "Last Name",
    "prenom" => "First Name",
    "email" => "Your E-mail",
    "message" => "Your message",
    "envoyer" => "Send",
    "titlecontact" => "Contact me",

    //page a propos
    "textabout" => "I am Abdolmohammadian Kian, a second-year Computer Science student at the University of Strasbourg. I love coding and I create content with Python.",
    "competence" => "Skills",
    "html" => "HTML/CSS",
    "python" => "Python",
    "c" => "C",
    "java" => "Java",
    "educationtitle" => "Education",
    "educationtext" => "I obtained Baccalauréat with honors in Mathematics, Physics-Chemistry, and Life Sciences. I studied Physics Measurement for one year and I am currently pursuing my Bachelor's degree in Computer Science.",
    "experiencetitle" => "Experience",
    "experiencetext" => "I have been studying computer science for almost 2 years now, and I have completed several projects, both within the framework of my studies and personally.",
    "experienceguessr" => "GuessrBot: Personal Discord bot project",
    "experiencesoko" => "Sokoban: Group project related to the degree",
    "experienceconduite" => "Driving application: Individual project related to the degree",
    "centreinteret" => "Interests",
    "centreinterettext" => "Besides coding, I enjoy playing video games, traveling, and playing volleyball with my friends.",
    "contacttext" => "For any inquiries, questions, or proposals, you can contact me via email or use the contact form.",
    "contactemail" => "Email: kian.abm67@gmail.com",

    //page projet
    "titleprojet" => "My Various Works",
    "guessrtitle" => "GuessrBot",
    "guessrtext" => "Discord bot offering geography quizzes, present on over 350 servers. Personal project developed since 2023.",
    "sokotitle" => "Sokoban",
    "sokotext" => "Recreation of the Sokoban game in C language on the terminal. Group project completed as part of my degree.",
    "conduitetitle" => "Driving Application",
    "conduitetext" => "Website for recording driving sessions. Individual project completed as part of my degree.",
    "conduitelink" => "Driving",

    
);
?>
