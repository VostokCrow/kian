<?php include("lang/langconfig.php"); ?>
<!doctype html>
<html lang="<?php echo $_SESSION['lang']; ?>">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible"
  content = "IE=edge">
  <meta name="viewport" content="width=device,
  initial-scale=1.0">
  <link rel ="stylesheet" href="css/styleform.css">
  <title>Contact</title>
</head>

<body>
    
    
    <header>
        <?php include('php/navbar.php'); ?>
    </header>
   
    <section>
        <div class="container">
            <h2><?php echo $lang['titlecontact'];?></h2>
                
                    <form action="php/traitement.php" method="POST" class="contact-form" id="idform">
                        <div class="form-group">
                            <label for="name"></label>
                            <input type="text" id="name" name="name" placeholder="<?php echo $lang['name'];?>" required>
                        </div>
                        <div class="form-group">
                            <label for="prenom"></label>
                            <input type="text" id="prenom" name="prenom" placeholder="<?php echo $lang['prenom'];?>" required>
                        </div>
                        <div class="form-group">
                            <label for="email"></label>
                            <input type="email" id="email" name="email" placeholder="<?php echo $lang['email'];?>" required>
                        </div>
                        <div class="form-group">
                            <label for="message"></label>
                            <textarea id="message" name="message" cols="30" rows="10" placeholder="<?php echo $lang['message'];?>" required></textarea>
                        </div>
                        <div class="btn">
                            <button type="submit" class="submit-button"><?php echo $lang['envoyer'];?></button>
                        </div>
                    </form>
            
        </div>
    </section>
    
    <?php include('php/footer.php'); ?>
    <script src="js/navbarscript.js"></script>
    <script src="js/validationavant.js"></script>
    <script src="js/validation.js"></script>
    <?php
    include("php/form_verif.php");
    ?>
</body>

</html>