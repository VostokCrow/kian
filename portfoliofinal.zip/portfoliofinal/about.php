<?php include("lang/langconfig.php"); ?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styleabout.css">
    <title>About</title>
</head>
<body>

  <header>
    <?php include('php/navbar.php'); ?>
  </header>

  <div class="container">
    <div class="content">
      <h1><?php echo $lang['about'];?></h1>
        <p><?php echo $lang['textabout'];?></p>
        <h2><?php echo $lang['competence'];?></h2>
        <ul>
          <li><?php echo $lang['html'];?></li>
          <li><?php echo $lang['python'];?></li>
          <li><?php echo $lang['c'];?></li>
          <li><?php echo $lang['java'];?></li>
        </ul>
        <h2><?php echo $lang['educationtitle'];?></h2>
        <p><?php echo $lang['educationtext'];?></p>
        <h2><?php echo $lang['experiencetitle'];?></h2>
        <p><?php echo $lang['experiencetext'];?></p>
        <ul>
          <li><?php echo $lang['experienceguessr'];?></li>
          <li><?php echo $lang['experiencesoko'];?></li>
          <li><?php echo $lang['experienceconduite'];?></li>
        </ul>
        <h2><?php echo $lang['centreinteret'];?></h2>
        <p><?php echo $lang['centreinterettext'];?></p>
        <h2><?php echo $lang['titlecontact'];?></h2>
        <p><?php echo $lang['contacttext'];?></p>
        <ul>
          <li><?php echo $lang['contactemail'];?></li>
        </ul>
    </div>
  </div>
  <?php include('php/footer.php'); ?>
  <script src="js/navbarscript.js"></script>
</body>
</html>
