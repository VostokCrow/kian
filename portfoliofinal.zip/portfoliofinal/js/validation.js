document.addEventListener("DOMContentLoaded", function() {
   
    const form = document.getElementById("idform");

    
    form.addEventListener("submit", function(event) {
        
        event.preventDefault();

        
        const name = document.getElementById("name").value;
        const prenom = document.getElementById("prenom").value;
        const email = document.getElementById("email").value;
        const message = document.getElementById("message").value;

        
        if (name.trim() === "" || prenom.trim() === "" || email.trim() === "" || message.trim() === "") {
            alert("Veuillez remplir tous les champs du formulaire.");
            return;
        }

        
        const nameRegex = /^[A-Za-zÀ-ÖØ-öø-ÿ\s-']+$/;
        if (!nameRegex.test(name)) {
            alert("Le nom ne doit contenir que des lettres.");
            return;
        }

        const prenomRegex = /^[A-Za-zÀ-ÖØ-öø-ÿ\s-']+$/;
        if (!prenomRegex.test(prenom)) {
            alert("Le prénom ne doit contenir que des lettres.");
            return;
        }

        
        if (confirm("Êtes-vous sûr de vouloir envoyer ce formulaire ?")) {
            
            fetch("php/traitement.php", {
                method: "POST",
                body: new FormData(form)
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error("Erreur lors de la requête.");
                }
                return response.text();
            })
            .then(data => {
                console.log(data); 
                alert("Formulaire envoyé avec succès !");
                
                form.reset();
            })
            .catch(error => {
                console.error(error);
                alert("Une erreur s'est produite. Veuillez réessayer.");
            });
        }
    });
});
