document.addEventListener("DOMContentLoaded", function () {
    const moreProjectsButton = document.getElementById("more-projects");
    let projectNumber = 0;
    let allProjectsLoaded = false;

    moreProjectsButton.addEventListener("click", loadNextProject);

    function loadNextProject() {
        if (!allProjectsLoaded) {
            fetch("php/get_projects.php?projectNumber=" + projectNumber + "&lang="+lang)
                .then(response => {
                    if (!response.ok) {
                        throw new Error("Erreur lors de la requête AJAX");
                    }
                    return response.json();
                })
                .then(project => {
                    if (project) {
                        const projectsContainer = document.querySelector(".projects");
                        const projectHTML = `
                            <li class="project">
                                <img src="${project.image}" alt="Image de la Terre" class="projetlogo">
                                <div class="project-info">
                                    <h4>${project.titre}</h4>
                                    <p>${project.description}</p>
                                </div>
                            </li>
                        `;
                        projectsContainer.insertAdjacentHTML("beforeend", projectHTML);
                        projectNumber++;
                    } else {
                        allProjectsLoaded = true;
                        moreProjectsButton.disabled = true; 
                    }
                })
                .catch(error => {
                    console.error("Erreur lors du chargement du projet:", error);
                });
        }
    }
});
