#!/bin/bash

CHEMIN_ABSOLU="/home/kian/Documents/L2/S4/PW2/abdolmohammadian-kian-projet-l2s4-pw2"

if [ ! -d "$CHEMIN_ABSOLU" ]; then
    echo "Chemin non valide"
    exit 1
fi

php -S localhost:8000 --docroot="$CHEMIN_ABSOLU"