# Portefolio Projet ProgWeb 2

## Description
Portefolio présentant différents projets réalisés, site web créé dans le cadre de Programmation Web 2.

## Fonctionnalités
- Appel Ajax pour la pagination
- Validation PHP/JS pour l'envoi du formulaire
- Sytème de traduction du site en PHP

## Installation
L'installation du projet s'est faite avec git et ses commandes comme `git init`, etc...
Le clonage du projet a été effectué avec la commande `https://git.unistra.fr/kabdolmohammadia/abdolmohammadian-kian-projet-l2s4-pw2.git`.

## Maquette du site
- image de la maquette
- choix de couleur : https://coolors.co/d0f1bf-b6d7b9-9abd97-7a7b44-4c410c
- choix de background : site haikei.app

## Utilisation et Informations
- La base de données a été créée avec SQLite, un repertoire Database a été créé pour contenir le fichier.
La manipulation de cette BdD et sa visualisation ont été possible avec l'extension SQlite de VSCode.
La création des tables et l'insertion des éléments descriptifs des projets pour la table Projet ont été faite avec la fonctionnalité Query de l'extension. (Open Database => New Query).
<!--
    Création d'une table avec SQLite dans un fichier Query temporaire

    CREATE TABLE IF NOT EXISTS Utilisateurs (
        id INTEGER PRIMARY KEY,
        nom TEXT NOT NULL,
        prenom TEXT NOT NULL,
        email TEXT NOT NULL,
        message TEXT NOT NULL
    );
--> 
- Le fichier `run_server.sh` permet de démarrer le serveur localhost et de visualiser le site et manipuler du code PHP.
la commande `\run_server.sh` permet de le démarrer.

- Le formulaire de contact est de type POST.
- A la base, le système de traduction devait être une sorte de "mini formulaire" de type GET avec la balise `<form>`, pour répondre aux critères d'évaluation.
Après considérations et par soucis d'esthétique, il a été remplacé par les images des drapeaux pour faciliter la compréhension de l'utilisateur. Cependant, le système est toujours de type GET.

## Technologies utilisées
- HTML
- CSS
- PHP/PDO
- SQL avec SQLite comme type de BDD
- JavaScript

## Contributeurs
- [Abdolmohammadian Kian](https://git.unistra.fr/kabdolmohammadia)

