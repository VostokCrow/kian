<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $name = trim($_POST["name"]);
    $prenom = trim($_POST["prenom"]);
    $email = trim($_POST["email"]);
    $message = trim($_POST["message"]);

    if (empty($name) || empty($prenom) || empty($email) || empty($message)) {
        echo "Tous les champs sont obligatoires.";
    } else {
        
        if (strlen($name) > 255) {
            echo "Le nom ne doit pas dépasser 255 caractères.";
        } elseif (strlen($prenom) > 255) {
            echo "Le prénom ne doit pas dépasser 255 caractères.";
        } elseif (strlen($message) > 255) {
            echo "Le message ne doit pas dépasser 255 caractères.";
        } else {
            
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                echo "Adresse email invalide.";
            } elseif (!is_string($name) || !is_string($prenom) || !is_string($message)) {
                echo "Erreur : Les données ne sont pas valides.";
            }
        }
    }
}
?>
