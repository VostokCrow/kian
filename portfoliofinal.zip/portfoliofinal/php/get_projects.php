<?php

$dbPath = 'sqlite:/home/kian/Documents/L2/S4/PW2/abdolmohammadian-kian-projet-l2s4-pw2/database/projet.sqlite';

try {
    $bdd = new PDO($dbPath);
} catch (PDOException $e) {
    die("Erreur : " . $e->getMessage());
}

$projectNumber = isset($_GET['projectNumber']) ? intval($_GET['projectNumber']) : 0;
$lang = isset($_GET['lang']) ? $_GET['lang'] : 'fr'; 


if ($lang === 'en') {
    $query = $bdd->prepare("SELECT id, titre_en AS titre, description_en AS description, image FROM projet LIMIT 1 OFFSET ?");
} else {
    $query = $bdd->prepare("SELECT id, titre, description, image FROM projet LIMIT 1 OFFSET ?");
}

$query->execute([$projectNumber]);
$project = $query->fetch(PDO::FETCH_ASSOC);

echo json_encode($project);
?>
