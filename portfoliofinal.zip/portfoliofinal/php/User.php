<?php
class User {
    private $conn;
    private $table = 'formulaire';

    public $id;
    public $nom;
    public $prenom;
    public $email;
    public $message;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create() {
        $query = 'INSERT INTO ' . $this->table . ' (nom, prenom, email, message) VALUES (:nom, :prenom, :email, :message)';

        $stmt = $this->conn->prepare($query);

        $this->nom = htmlspecialchars(strip_tags($this->nom));
        $this->prenom = htmlspecialchars(strip_tags($this->prenom));
        $this->email = htmlspecialchars(strip_tags($this->email));
        $this->message = htmlspecialchars(strip_tags($this->message));

        $stmt->bindParam(':nom', $this->nom);
        $stmt->bindParam(':prenom', $this->prenom);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':message', $this->message);

        if($stmt->execute()) {
            return true;
        }

        printf("Erreur : %s.\n", $stmt->error);

        return false;
    }
}
?>
