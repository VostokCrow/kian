<?php
include_once 'Database.php';
include_once 'User.php';


$database = new Database();
$db = $database->connect();


$user = new User($db);


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    if(isset($_POST['name'], $_POST['prenom'], $_POST['email'], $_POST['message'])) {
        
        $nom = htmlspecialchars($_POST['name']);
        $prenom = htmlspecialchars($_POST['prenom']);
        $email = htmlspecialchars($_POST['email']);
        $message = htmlspecialchars($_POST['message']);

        
        $user->nom = $nom;
        $user->prenom = $prenom;
        $user->email = $email;
        $user->message = $message;

        
        if($user->create()) {
            echo 'Formulaire transmis !';
        } else {
            echo 'Erreur lors de l\'envoi du formulaire.';
        }
    }
}
?>
