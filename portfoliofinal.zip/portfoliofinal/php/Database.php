<?php
class Database {
    private $db_name = '/home/kian/Documents/L2/S4/PW2/abdolmohammadian-kian-projet-l2s4-pw2/database/db.sqlite';
    private $conn;

    public function connect() {
        $this->conn = null;

        try {
            $this->conn = new PDO('sqlite:' . $this->db_name);
            $this->conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch(PDOException $e) {
            echo 'Erreur de connexion : ' . $e->getMessage();
        }

        return $this->conn;
    }
}

?>
