<footer><p><?php echo $lang['footer'];?><p></footer>
