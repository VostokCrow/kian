<nav class="navbar">
    <img src="img/menu-btn.png" alt="menu hamburger" class="menu-hamburger">
    <div class="nav-links">
        <ul>
            <li class="active"><a href="index.php"><?php echo $lang['homepage']; ?></a></li>
            <li><a href="projet.php"><?php echo $lang['project']; ?></a></li>
            <li><a href="contact.php"><?php echo $lang['contact']; ?></a></li>
            <li><a href="about.php"><?php echo $lang['about']; ?></a></li>
        </ul>
    </div>
</nav>
