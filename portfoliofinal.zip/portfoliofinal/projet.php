<?php include("lang/langconfig.php"); ?>
<!doctype html>
<html lang="<?php echo $_SESSION['lang']; ?>">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible"
  content = "IE=edge">
  <meta name="viewport" content="width=device,
  initial-scale=1.0">
  <link rel ="stylesheet" href="css/style.css">
  <title>Projets</title>
</head>

<body>
  
  <header id="projetheader">
    <?php include('php/navbar.php'); ?>
  </header>   
  <main>
        <section id="portfolio">
            <h3><?php echo $lang['titleprojet']; ?></h3>
            <ul class="projects">
              <li class="project">
                <img src="img/earth.png" alt="Image de la Terre" class="guessr_logo">
                <div class="project-info">
                  <h4><?php echo $lang['guessrtitle']; ?></h4>
                  <p><?php echo $lang['guessrtext']; ?></p>
                </div>
              </li>
              <li class="project">
                <img src="img/soko.png" alt="Image d'un bonhomme qui court" class="sokoban_logo">
                <div class="project-info">
                  <h4><?php echo $lang['sokotitle']; ?></h4>
                  <p><?php echo $lang['sokotext']; ?></p>
                </div>
              </li>
              <li class="project">
                <img src="img/voiture.png" alt="Image d'une voiture" class="conduite_logo">
                <div class="project-info">
                  <h4><?php echo $lang['conduitetitle']; ?></h4>
                  <p><?php echo $lang['conduitetext']; ?></p>
                </div>
              </li>
            </ul>
            <div class="project-links">
                <a href="https://top.gg/bot/1071788674380996628" target="_blank" rel="noopener noreferrer">GuessrBot</a>
                <a href="https://git.unistra.fr/kabdolmohammadia/sokoban" target="_blank" rel="noopener noreferrer">Sokoban</a>
                <a href="https://kian.alwaysdata.net/conduite/index.html" target="_blank" rel="noopener noreferrer"><?php echo $lang['conduitelink']; ?></a>
            </div>
            
          </section>
    </main>

    
    <?php include('php/footer.php'); ?>
  <script src="js/navbarscript.js"></script>
    
</body>
</html>